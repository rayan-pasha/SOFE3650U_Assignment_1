public class Banana implements GroceryProduct{

    @Override
    public void getGrocery() {

        System.out.println("A Banana costs");
    }
}
