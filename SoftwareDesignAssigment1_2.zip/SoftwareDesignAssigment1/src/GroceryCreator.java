import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.io.IOException;
import java.io.*;
public class GroceryCreator {
    public static void main(String[] args) {

        String[] data = new String[4];
        try {
            File myObj = new File("Grocery.txt");
            Scanner myReader = new Scanner(myObj);

            int i = 0;

            while (myReader.hasNextLine()) {

                data[i] = myReader.nextLine();

                i++;
                    //System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        AbstractGroceryProductFactory factory1 = GroceryProductProducer.getFactory();
        GroceryProduct fruit1 = factory1.getGrocery(data[0]);
        fruit1.getGrocery();
        System.out.println(2.99);
        GroceryProduct fruit2 = factory1.getGrocery(data[2]);
        fruit2.getGrocery();
        System.out.println(1.99);


    }
}
