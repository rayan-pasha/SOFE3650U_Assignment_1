import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GroceryProductFactory extends AbstractGroceryProductFactory{

    @Override
     public GroceryProduct getGrocery(String product) {

        switch (product) {

            case "Apple":
                return new Apple();
            case "2.99":
                System.out.println(product);
                break;
            case "Banana":
                return new Banana();
            case "1.99":
                System.out.println(product);
                break;
            default:
        }
        return new Apple();
    }
}
