public abstract class AbstractGroceryProductFactory {
    abstract GroceryProduct getGrocery(String product);
}
