public class Apple implements GroceryProduct {

    public void getGrocery() {

        System.out.println("An Apple costs");
    }

}
