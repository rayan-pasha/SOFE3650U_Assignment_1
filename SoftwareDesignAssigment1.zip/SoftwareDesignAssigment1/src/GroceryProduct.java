public interface GroceryProduct {
    void getGrocery();
};
