public class GroceryProductProducer {

    public static AbstractGroceryProductFactory getFactory() {

        return new GroceryProductFactory();
    }



    }
