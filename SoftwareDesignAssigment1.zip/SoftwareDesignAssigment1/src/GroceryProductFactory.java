public class GroceryProductFactory extends AbstractGroceryProductFactory{

    @Override
     public GroceryProduct getGrocery(String product) {

        System.out.println(product);
        if (product == "Apple") {
           return new Apple();
        } else if (product == "Banana") {
            return new Banana();
        } else
             return null;
    }
}
