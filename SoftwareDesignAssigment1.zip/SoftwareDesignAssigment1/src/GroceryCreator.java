import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.io.IOException;
import java.io.*;
public class GroceryCreator {
    public static void main(String[] args) {

        try {
            File myObj = new File("Grocery.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                    AbstractGroceryProductFactory factory1 = GroceryProductProducer.getFactory();
                    GroceryProduct fruit1 = factory1.getGrocery(data);
                    fruit1.getGrocery();
                    //System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }


    }
}
